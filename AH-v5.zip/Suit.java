public enum Suit {

Clubs, Diamonds, Spades, Hearts

}