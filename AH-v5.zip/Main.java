import java.util.*;
import java.io.*;

class Main {
  public static void main(String[] args) throws IOException, NumberFormatException{
      Trumps AHProject = new Trumps();
    AHProject.processTrumps();

      //Leaderboard Leaderboard = new Leaderboard();
       // Leaderboard.processLeaderboard();

  }
}